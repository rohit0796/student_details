import React from 'react'

function footer() {
  return (
    <div>
      
    </div>
  )
}

export default footer
